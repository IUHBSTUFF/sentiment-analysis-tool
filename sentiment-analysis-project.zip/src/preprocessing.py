import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import spacy

nltk.download("stopwords")
nltk.download("wordnet")

df = pd.read_csv("../data/raw/reviews.csv")

lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words("english"))
nlp = spacy.load("en_core_web_sm")

def preprocess(text):
    doc = nlp(text.lower())
    tokens = [lemmatizer.lemmatize(token.text) for token in doc if token.is_alpha and token.text not in stop_words]
    return " ".join(tokens)

df["clean_text"] = df["text"].apply(preprocess)
df.to_csv("../data/processed/clean_reviews.csv", index=False)
