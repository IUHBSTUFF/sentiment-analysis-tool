# Sentiment Analysis Project

Phase 2 – Implementation & Model Comparison  
Author: Jan Alexander Heege

## Project Objective
This project builds a sentiment analysis tool that compares:
1. Rule-based (VADER)
2. Machine Learning (SVM)
3. Deep Learning (BERT)

## Structure
- notebooks/ → Jupyter notebooks (preprocessing, model training, visualization)
- src/ → python scripts for models
- data/ → raw and processed data

## Run
```
pip install -r requirements.txt
jupyter notebook
```
