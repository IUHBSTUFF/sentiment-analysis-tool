# Sentiment Pipeline

A reference implementation for classifying sentiment/emotions in text.

## Getting started
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pre-commit install
```

## Quick run
```bash
python -m sentiment_pipeline.train --data data/raw/sample_reviews.csv
python -m sentiment_pipeline.serve --host 0.0.0.0 --port 8000
```

## Coding standards
- **PEP 8** (style) and **PEP 257** (docstrings)
- Type hints everywhere
- Black + isort formatting
- Flake8 linting in CI

## Framework links
- Scrapy: https://scrapy.org/
- BeautifulSoup: https://www.crummy.com/software/BeautifulSoup/bs4/doc/
- Tweepy: https://www.tweepy.org/
- NLTK: https://www.nltk.org/
- spaCy: https://spacy.io/
- VADER: https://ojs.aaai.org/index.php/ICWSM/article/view/14550
- BERT: https://en.wikipedia.org/wiki/BERT_(language_model)
- Flask: https://flask.palletsprojects.com/en/stable/api/
- Kafka Streams: https://kafka.apache.org/documentation/streams/
