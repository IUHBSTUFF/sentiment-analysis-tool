"""Model training entry point.

- Baselines: VADER
- Classical ML: SVM + TF-IDF
- Deep: BERT fine-tuning (skeleton)
"""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from .utils import clean_text

def train_ml(df: pd.DataFrame) -> Pipeline:
    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=50000, ngram_range=(1,2))),
        ("clf", LinearSVC())
    ])
    return pipe.fit(df["text"], df["label"])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=str, required=True, help="CSV with columns: text,label")
    args = ap.parse_args()

    df = pd.read_csv(args.data)
    df["text"] = df["text"].astype(str).map(clean_text)
    train, test = train_test_split(df, test_size=0.2, random_state=42, stratify=df["label"])

    model = train_ml(train)
    preds = model.predict(test["text"])
    print(classification_report(test["label"], preds))

    # Baseline example: VADER on a few samples
    analyzer = SentimentIntensityAnalyzer()
    for s in test["text"].head(3):
        print(s, analyzer.polarity_scores(s))

if __name__ == "__main__":
    main()
