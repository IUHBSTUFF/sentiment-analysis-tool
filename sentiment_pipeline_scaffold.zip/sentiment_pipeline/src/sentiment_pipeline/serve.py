"""Simple Flask API for inference."""
from __future__ import annotations
from typing import Dict, Any
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health() -> Dict[str, Any]:
    return {"status": "ok"}

@app.route("/predict", methods=["POST"])
def predict() -> Dict[str, Any]:
    payload = request.get_json() or {}
    text = str(payload.get("text", ""))
    # Placeholder: return neutral; integrate with trained model in production.
    return jsonify({"text": text, "sentiment": "neutral", "score": 0.0})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
