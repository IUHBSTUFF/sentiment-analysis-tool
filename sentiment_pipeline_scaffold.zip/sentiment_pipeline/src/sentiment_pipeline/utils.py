"""Utility functions for text preprocessing.

Follows PEP 8 and PEP 257 with type hints.
"""
from __future__ import annotations
from typing import Iterable, List
import re

def clean_text(text: str) -> str:
    """Basic cleaning: lowercasing and URL/mention removal."""
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"@[\w_]+", " ", text)
    text = re.sub(r"[^\w\s\-\.!?]", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def tokens_to_ngrams(tokens: Iterable[str], n: int = 2) -> List[str]:
    """Create n-grams from a token sequence."""
    toks = list(tokens)
    return [" ".join(toks[i:i+n]) for i in range(len(toks)-n+1)]
