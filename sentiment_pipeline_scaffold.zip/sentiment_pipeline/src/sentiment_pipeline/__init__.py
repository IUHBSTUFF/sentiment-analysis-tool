"""
sentiment_pipeline package.
"""
